﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeTravelBooking_new
{
    /// <summary>
    /// Interaction logic for AdminLogin.xaml
    /// </summary>
    public partial class AdminLogin : Window
    {

        SqlCommand cmd = new SqlCommand();
        SqlConnection con = new SqlConnection();

        SqlDataAdapter sda = new SqlDataAdapter();
        DataSet ds = new DataSet();
        public AdminLogin()
        {
            con.ConnectionString = @"data Source= ndamssql\sqlilearn;user id=sqluser;password=sqluser;initial catalog =training_19sep18_pune;"; ;
            con.Open();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            cmd.CommandText = "select * from cd_mini_adminLogin where UserName='" + txt_name_admin.Text + "'and _Password = '" + txt_pass_admin.Text + "'";
            cmd.Connection = con;
            sda.SelectCommand = cmd;
            sda.Fill(ds, "cd_login_table");

            if (ds.Tables[0].Rows.Count > 0)
            {

                label2_admin.Content = "Data Found";

                var admin = new Admin();
                admin.Show();
            }
            else
            {
                label2_admin.Content = "Data Not Found";
            }
        }
    }
}
