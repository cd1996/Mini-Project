﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeTravelBookingSystem
{
    /// <summary>
    /// Interaction logic for AdminForm.xaml
    /// </summary>
    public partial class AdminForm : Window
    {
        public AdminForm()
        {
            InitializeComponent();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            CanvasAddTravelAgent.Visibility = Visibility.Hidden;
            CanvasAssignManager.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            CanvasAddTravelAgent.Visibility = Visibility.Hidden;
            CanvasAssignManager.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            CanvasAddTravelAgent.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Hidden;
            CanvasAssignManager.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            CanvasAssignManager.Visibility = Visibility.Hidden;
            CanvasDeleteEmployee.Visibility = Visibility.Hidden;
            CanvasAddEmployee.Visibility = Visibility.Hidden;
            CanvasAddTravelAgent.Visibility = Visibility.Visible;
        }
    }
}
